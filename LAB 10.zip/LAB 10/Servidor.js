const express = require('express');
const path = require('path');
const { MongoClient, ObjectId } = require('mongodb');

const app = express();
const mongoUrl = 'mongodb://127.0.0.1:27017';
const dbName = 'lab10';

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

let usuarios;
let carros;

function formatMensagem(texto) {
  return texto.replace(/\n/g, '<br>');
}

MongoClient.connect(mongoUrl, { useUnifiedTopology: true })
  .then((client) => {
    const db = client.db(dbName);
    usuarios = db.collection('usuarios');
    carros = db.collection('carros');

    app.listen(80, () => {
      console.log('Servidor rodando na porta 80');
    });
  })
  .catch((err) => {
    console.error('Erro ao conectar ao MongoDB:', err);
  });

app.get('/', (req, res) => res.redirect('/projects'));

app.get('/projects', async (req, res) => {
  const usuariosCount = await usuarios.countDocuments();
  const carrosCount = await carros.countDocuments();
  res.render('projects', { usuariosCount, carrosCount });
});

app.get('/cadastro_usuario', (req, res) => {
  res.render('cadastro_usuario');
});

app.post('/cadastrar_usuario', async (req, res) => {
  const data = { nome: req.body.nome, login: req.body.login, senha: req.body.senha };
  try {
    await usuarios.insertOne(data);
    res.render('resposta', { mensagem: 'Usuário cadastrado com sucesso!' });
  } catch (err) {
    res.render('resposta', { mensagem: 'Erro ao cadastrar usuário! ' + formatMensagem(err.message) });
  }
});

app.get('/login_usuario', (req, res) => {
  res.render('login_usuario');
});

app.post('/logar_usuario', async (req, res) => {
  const data = { login: req.body.login, senha: req.body.senha };
  try {
    const usuario = await usuarios.findOne(data);
    if (!usuario) {
      res.render('resposta', { mensagem: 'Usuário/senha não encontrado!' });
    } else {
      res.render('resposta', { mensagem: 'Usuário logado com sucesso!' });
    }
  } catch (err) {
    res.render('resposta', { mensagem: 'Erro ao logar usuário! ' + formatMensagem(err.message) });
  }
});

app.get('/carros', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'Projects.html'));
});

app.get('/gerenciar_carros', async (req, res) => {
  const listaCarros = await carros.find().toArray();
  res.render('gerenciar_carros', { carros: listaCarros });
});

app.get('/novo_carro', (req, res) => {
  res.render('novo_carro');
});

app.post('/cadastrar_carro', async (req, res) => {
  const data = {
    marca: req.body.marca,
    modelo: req.body.modelo,
    ano: parseInt(req.body.ano, 10),
    qtde_disponivel: parseInt(req.body.qtde_disponivel, 10)
  };
  try {
    await carros.insertOne(data);
    res.render('resposta', { mensagem: 'Carro cadastrado com sucesso!' });
  } catch (err) {
    res.render('resposta', { mensagem: 'Erro ao cadastrar carro! ' + formatMensagem(err.message) });
  }
});

app.get('/remover_carro', async (req, res) => {
  const listaCarros = await carros.find().toArray();
  res.render('remover_carro', { carros: listaCarros });
});

app.post('/remover_carro', async (req, res) => {
  try {
    const result = await carros.deleteOne({ _id: new ObjectId(req.body.id) });
    if (result.deletedCount === 0) {
      res.render('resposta', { mensagem: 'Carro não encontrado para remoção.' });
    } else {
      res.render('resposta', { mensagem: 'Carro removido com sucesso!' });
    }
  } catch (err) {
    res.render('resposta', { mensagem: 'Erro ao remover carro! ' + formatMensagem(err.message) });
  }
});

app.get('/atualizar_carro', async (req, res) => {
  if (!req.query.id) {
    return res.render('atualizar_carro', { carro: null });
  }

  try {
    const carro = await carros.findOne({ _id: new ObjectId(req.query.id) });
    res.render('atualizar_carro', { carro });
  } catch (err) {
    res.render('resposta', { mensagem: 'Erro ao carregar carro! ' + formatMensagem(err.message) });
  }
});

app.post('/atualizar_carro', async (req, res) => {
  try {
    const filtro = { _id: new ObjectId(req.body.id) };
    const atualizacao = {
      $set: {
        marca: req.body.marca,
        modelo: req.body.modelo,
        ano: parseInt(req.body.ano, 10),
        qtde_disponivel: parseInt(req.body.qtde_disponivel, 10)
      }
    };
    const result = await carros.updateOne(filtro, atualizacao);
    if (result.matchedCount === 0) {
      res.render('resposta', { mensagem: 'Carro não encontrado para atualização.' });
    } else {
      res.render('resposta', { mensagem: 'Carro atualizado com sucesso!' });
    }
  } catch (err) {
    res.render('resposta', { mensagem: 'Erro ao atualizar carro! ' + formatMensagem(err.message) });
  }
});

app.get('/vender_carro', async (req, res) => {
  const listaCarros = await carros.find().toArray();
  res.render('vender_carro', { carros: listaCarros });
});

app.post('/vender_carro', async (req, res) => {
  try {
    const filtro = { _id: new ObjectId(req.body.id) };
    const carro = await carros.findOne(filtro);
    if (!carro) {
      return res.render('resposta', { mensagem: 'Carro não encontrado.' });
    }
    if (carro.qtde_disponivel <= 0) {
      return res.render('resposta', { mensagem: 'Esgotado. Não é possível vender.' });
    }
    const result = await carros.updateOne(filtro, { $inc: { qtde_disponivel: -1 } });
    if (result.modifiedCount === 0) {
      res.render('resposta', { mensagem: 'Erro ao vender carro.' });
    } else {
      const atualizado = await carros.findOne(filtro);
      if (atualizado.qtde_disponivel === 0) {
        res.render('resposta', { mensagem: 'Carro vendido com sucesso! Esgotado.' });
      } else {
        res.render('resposta', { mensagem: 'Carro vendido com sucesso!' });
      }
    }
  } catch (err) {
    res.render('resposta', { mensagem: 'Erro ao vender carro! ' + formatMensagem(err.message) });
  }
});

