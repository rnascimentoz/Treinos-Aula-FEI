var http = require('http');
var express = require('express');
var colors = require('colors');
var bodyParser = require('body-parser');
var db = require('./db');

var app = express();
app.use(express.static('./public'));
app.use(bodyParser.urlencoded({ extended: false}))
app.use(bodyParser.json())
app.set('view engine', 'ejs')
app.set('views', './views');

var server = http.createServer(app);
server.listen(80);

console.log('Servidor rodando ...'.rainbow);

// Conectar ao banco de dados ao iniciar o servidor
db.conectarBD();

// Rota padrão - Direciona para Projects.html
app.get('/', function (requisicao, resposta){
    resposta.redirect('Projects.html')
})

app.get('/inicio', function (requisicao, resposta){
var nome = requisicao.query.info;
console.log(nome);
})

app.post('/inicio', function (requisicao, resposta){
var data = requisicao.body.data;
console.log(data);
})

app.get('/cadastro',function (requisicao, resposta){
var nome = requisicao.query.nome;
var sobrenome = requisicao.query.sobrenome;
var nascimento = requisicao.query.nascimento;
var civil = requisicao.query.civil;

resposta.render('resposta_cadastro', {nome, sobrenome, nascimento, civil})
})

// Rota para exibir a página do blog com todos os posts
app.get('/blog', async function (requisicao, resposta) {
    try {
        const posts = await db.buscarTodosPosts();
        resposta.render('blog', { posts: posts });
    } catch (error) {
        console.error('Erro ao buscar posts:', error);
        resposta.render('blog', { posts: [] });
    }
});

// Rota para exibir a página de cadastro de novo post
app.get('/cadastrar-post', function (requisicao, resposta) {
    resposta.sendFile(__dirname + '/public/cadastrar_post.html');
});

// Rota para receber o formulário e cadastrar novo post
app.post('/criar-post', async function (requisicao, resposta) {
    try {
        const { titulo, resumo, conteudo } = requisicao.body;
        
        // Validar se os campos foram preenchidos
        if (!titulo || !resumo || !conteudo) {
            return resposta.status(400).send('Todos os campos são obrigatórios!');
        }
        
        // Cadastrar o post no banco de dados
        await db.cadastrarPost(titulo, resumo, conteudo);
        
        // Redirecionar para a página do blog
        resposta.redirect('/blog');
    } catch (error) {
        console.error('Erro ao criar post:', error);
        resposta.status(500).send('Erro ao criar o post');
    }
});
