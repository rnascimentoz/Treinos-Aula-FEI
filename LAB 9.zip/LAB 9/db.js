// db.js - Módulo de acesso ao banco de dados MongoDB

const { MongoClient } = require('mongodb');

const url = 'mongodb://localhost:27017';
const dbName = 'blog_db';
const collectionName = 'posts';

let db;
let client;

// Conectar ao banco de dados
async function conectarBD() {
    try {
        client = new MongoClient(url, { useUnifiedTopology: true });
        await client.connect();
        db = client.db(dbName);
        
        // Criar collection se não existir
        const collections = await db.listCollections().toArray();
        const collectionExists = collections.some(col => col.name === collectionName);
        
        if (!collectionExists) {
            await db.createCollection(collectionName);
        }
        
        console.log('Conectado ao MongoDB com sucesso!'.green);
    } catch (error) {
        console.error('Erro ao conectar ao MongoDB:', error);
        throw error;
    }
}

// Cadastrar um novo post
async function cadastrarPost(titulo, resumo, conteudo) {
    try {
        const collection = db.collection(collectionName);
        
        const novoPost = {
            titulo: titulo,
            resumo: resumo,
            conteudo: conteudo,
            dataCriacao: new Date()
        };
        
        const resultado = await collection.insertOne(novoPost);
        console.log('Post cadastrado com sucesso!'.green, resultado.insertedId);
        return resultado;
    } catch (error) {
        console.error('Erro ao cadastrar post:', error);
        throw error;
    }
}

// Buscar todos os posts
async function buscarTodosPosts() {
    try {
        const collection = db.collection(collectionName);
        
        // Ordenar por data de criação em ordem decrescente
        const posts = await collection
            .find({})
            .sort({ dataCriacao: -1 })
            .toArray();
        
        console.log(`${posts.length} posts encontrados`.green);
        return posts;
    } catch (error) {
        console.error('Erro ao buscar posts:', error);
        throw error;
    }
}

// Desconectar do banco de dados
async function desconectarBD() {
    try {
        if (client) {
            await client.close();
            console.log('Desconectado do MongoDB'.yellow);
        }
    } catch (error) {
        console.error('Erro ao desconectar:', error);
    }
}

module.exports = {
    conectarBD,
    cadastrarPost,
    buscarTodosPosts,
    desconectarBD
};
